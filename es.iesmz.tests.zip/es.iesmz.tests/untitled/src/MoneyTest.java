import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MoneyTest {

    @Test
    public void testChange1(){
        Money m1= new Money();
        assertEquals(28.37f, m1.change(TipoMoneda.GBP, TipoMoneda.EUR,1165.83f),0.1f);
    }

    @Test
    public void testChange2() {
        Money m1= new Money();
        assertEquals(1165.83f, m1.change(TipoMoneda.GBP, TipoMoneda.EUR,1165.83f), 0.1f);
    }

    @Test
    public void testChange3() {
        Money m1= new Money();
        assertEquals(201.21f, m1.change(TipoMoneda.EUR, TipoMoneda.GBP,201.21f), 0.1f);
    }

    @Test
    public void testChange4() {
        Money m1= new Money();
        assertEquals(37.51f, m1.change(TipoMoneda.USD, TipoMoneda.EUR, 37.51f), 0.1f);
    }

    @Test
    public void testChange5() {
        Money m1= new Money();
        assertEquals(138.49f, m1.change(TipoMoneda.GBP, TipoMoneda.USD, 100.0f), 0.1f);

    }

    @Test
    public void testChange6() {
        Money m1= new Money();
        assertEquals(722.14f, m1.change(TipoMoneda.USD, TipoMoneda.GBP, 100.0f), 0.1f);

    }

    @Test
    public void testChange7() {
        Money m1= new Money();
        assertEquals(-1f, m1.change(TipoMoneda.PTS, TipoMoneda.EUR, 100.0f), 0.1f);

    }

    @Test
    public void testChange8() {
        Money m1= new Money();
        assertEquals(-1f, m1.change(TipoMoneda.EUR, TipoMoneda.PTS, 123.3f), 0.1f);

    }
    @Test
    public void testChange9() {
        Money m1= new Money();
        assertEquals(-1f, m1.change(TipoMoneda.USD, TipoMoneda.EUR, -167.34f));

    }
}