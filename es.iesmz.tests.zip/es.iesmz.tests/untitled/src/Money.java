public class Money {


    public static float change(TipoMoneda origen, TipoMoneda destino, float money){
        float result= 0f;
        final float eurAusd= 1.18798f;
        final float usdAeur= 0.841815f;
        final float eurAgbp= 0.857839f;
        final float gbpAeur= 1.165826f;

       if (money > 1f) {
           if (origen == TipoMoneda.EUR && destino == TipoMoneda.USD) result= money * eurAusd;
           if (origen == TipoMoneda.USD && destino == TipoMoneda.EUR) result= money *  usdAeur;
           if (origen == TipoMoneda.EUR && destino == TipoMoneda.GBP) result= money *  eurAgbp;
           if (origen == TipoMoneda.GBP && destino == TipoMoneda.EUR) result= money * gbpAeur;

       }else {
           return -1;
       }

        return result;
    }



}
