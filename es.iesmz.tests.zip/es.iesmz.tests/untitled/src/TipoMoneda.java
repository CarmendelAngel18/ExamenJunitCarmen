public enum TipoMoneda {
    EUR,USD,GBP, PTS;
}
